import React from 'react'

function AdminDashboard() {
  return (
    <div>AdminDashboard</div>
  )
}

export default AdminDashboard