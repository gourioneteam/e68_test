import React from 'react'

function CommonDashboard() {
  return (
    <div>CommonDashboard</div>
  )
}

export default CommonDashboard